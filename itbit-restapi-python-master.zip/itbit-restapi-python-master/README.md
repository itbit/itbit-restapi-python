# itBit API Python Wrapper

Use this wrapper to connect to the itBit API

## Requirements

Use pip to install the dependencies

## Compatibility

Tested with python 2.7.6 and 3.4.0

